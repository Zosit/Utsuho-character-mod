## Character mod for game Lost Branch of Legend
Adds Utsuho as a character. Includes starter exhibits, character specific cards, and a boss fight. 
Still missing most card and character art. Let me know if you want to contribute in the LBoL discord!
https://discord.gg/CX9BABzA



-- Mod Credits --

ZUN in Team Shanghai Alice for creating Touhou Project.

Alioth Studio for making Lost Branch of Legends.

Programmer/Designer:
- Zosit

Artists:
- Zosit
- Xeno
- Flippin'Loser

Translators:
- Xeno (English edit)
- Raspberry Caffeine Monster (Korean translations)

Special Thanks:
- NeoShrimp for making the Sideloader and Watermark mods used in this mod
- Everyone on the Discord who chatted and commented about coding or design (special notice to Lvalon and IntoxicatedKid)